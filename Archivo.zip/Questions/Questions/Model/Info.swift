//
//  Info.swift
//  Questions
//
//  Created by Oscar Valdes on 11/10/23.
//

import SwiftUI


//Modelo de la informacion de los ciestionarios
struct Info: Codable{
    var title: String
    var peopleAttended: Int
    var rules:[String]
    
    enum CodingKeys: CodingKey {
        case title
        case peopleAttended
        case rules
    }
}
