//
//  Notas+CoreDataProperties.swift
//  Chipil
//
//  Created by Oscar Roberto Valdes on 17/09/23.
//
//

import Foundation
import CoreData


extension Notas {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Notas> {
        return NSFetchRequest<Notas>(entityName: "Notas")
    }

    @NSManaged public var fecha: Date?
    @NSManaged public var id: UUID?
    @NSManaged public var nota: String?
    @NSManaged public var visto: Bool

}

extension Notas : Identifiable {

}
