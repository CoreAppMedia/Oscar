//
//  Notas+CoreDataClass.swift
//  Chipil
//
//  Created by Oscar Roberto Valdes on 17/09/23.
//
//

import Foundation
import CoreData

@objc(Notas)
public class Notas: NSManagedObject {

}
