//
//  AgregarNota.swift
//  Chipil
//
//  Created by Oscar Roberto Valdes on 17/09/23.
//

import SwiftUI
import CoreData
struct AgregarNota: View {
    
    @Environment(\.managedObjectContext) private var moc
    @Environment(\.dismiss) private var dismiss

    @State private var nota: String = ""
    @State private var counter = 0
    @State private var text = "Escribe algo"
  
    var body: some View {
        NavigationView{
            VStack{
                TextEditor(text: self.$nota)
                    .font(.title)
                    .autocapitalization(.none)
                    .disableAutocorrection(true)
                    .foregroundColor(.blue)
                    .padding()
                    .onChange(of: nota, perform: { value in
                        counter = value.count
                    })
                
                Text("\(counter)")

                    Button(action: {
                        let agregar = Notas(context: self.moc)
                        agregar.nota = self.nota
                        agregar.fecha = Date()
                        agregar.id = UUID()
                        
                        try! self.moc.save()
                        dismiss()
                    }){
                        Text("Agregar")
                    }.disabled(self.nota.count > 0 ? false: true)
                    .font(.title)
                    .padding()
                
               
            }.navigationTitle("Agregar nueva Nota")
        }
    }
}
struct AgregarNota_Previews: PreviewProvider {
    static var previews: some View {
        AgregarNota()
    }
}
