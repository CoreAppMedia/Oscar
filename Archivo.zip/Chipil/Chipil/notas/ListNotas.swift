//
//  ListNotas.swift
//  Chipil
//
//  Created by Oscar Valdes on 18/09/23.
//

import SwiftUI

struct ListNotas: View {
    
    @ObservedObject var authenticationViewModel: AuthenticationViewModel
    
    @Environment(\.managedObjectContext) private var moc
    @FetchRequest(
        sortDescriptors: [NSSortDescriptor(keyPath: \Notas.fecha, ascending: true),
                          NSSortDescriptor(keyPath: \Notas.id, ascending: true)],
        
        animation: .default)
    private var notas: FetchedResults<Notas>
    
    static var fechaFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .full
        return formatter
    }()

    
    var fecha = Date()
    
    @State private var mostrar: Bool = false
    
    
    
    var body: some View {
        
        NavigationView{
            ZStack{
             //   Color("blue_1").opacity(1).edgesIgnoringSafeArea(.all)
                List{
                    ForEach(notas, id: \.id){  nota in
                        HStack{
                            Button(action: {
                                nota.visto.toggle()
                                
                                try! self.moc.save()
                            }){
                                Image(systemName: nota.visto ?"checkmark.rectangle.fill" : "checkmark.rectangle")
                                    .font(.headline.bold())
                                    .foregroundColor(nota.visto ?.green : .gray)
                            }
                            VStack(alignment: .leading){
                                
                                Text(nota.nota ?? "")
                                    .font(.headline)
                                    .foregroundColor(.primary)
                                Text("\(nota.fecha ?? self.fecha, formatter: Self.fechaFormatter)")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }.strikethrough(nota.visto ? true: false)
                            Spacer()
                            if nota.visto{
                                Text("Hecho Master")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                        }//LLave del Hstack
                        
                    }//llave del ForEach
                    .onDelete(perform: borrar )
                }// llave de la lista
                .navigationBarTitleDisplayMode(.inline)
                .navigationTitle("Bienvenido")
                .toolbar{
                    ToolbarItem(placement: .navigationBarTrailing){
                        Button(action: {
                            self.mostrar.toggle()
                        }){
                            Image(systemName: "plus")
                                .resizable().frame(width: 30 ,height: 30)
                        }
                    }
                    
                }// llave Toolbar
                .sheet(isPresented: self.$mostrar,content: {
                    AgregarNota().environment(\.managedObjectContext, self.moc)
                })
            }
        }
    }
    
    func borrar(de nota: IndexSet){
        for index in nota{
            let eliminar = notas[index]
            self.moc.delete(eliminar)
        }
    }
}

private let itemFormatter: DateFormatter = {
    let formatter = DateFormatter()
    formatter.dateStyle = .short
    formatter.timeStyle = .medium
    return formatter
}()

struct ListNotas_Previews: PreviewProvider {
    static var previews: some View {
        ListNotas(authenticationViewModel: AuthenticationViewModel())
    }
}
