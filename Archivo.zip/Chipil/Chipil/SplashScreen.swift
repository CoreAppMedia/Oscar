//
//  SplashScreen.swift
//  Intro
//
//  Created by Oscar Roberto Valdes on 07/10/23.
//

import SwiftUI

struct SplashScreen: View {
    @State var AnimacionFInalizar: Bool = false
    @State var RemoverAnimacion: Bool = false
    
    
    var body: some View {
        ZStack{
        //    Home()
            ZStack{
                Color("blue1").ignoresSafeArea()
                ZStack{
                  
                    if !RemoverAnimacion{
                        VStack{
                            Image("nombre").resizable().frame(width: 420 ,height: 120, alignment: .center)
                            Image("ChipilPortada").resizable().frame(width: 200 ,height: 300, alignment: .center)
                        }//llave del VStack
                    }
                }//llave ZStack

                        }//llave ZStack final
                        .opacity(AnimacionFInalizar ? 0 : 1)
            
            
            
        }
                    .onAppear{
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2){
                            withAnimation(.easeInOut(duration: 1)){
                                AnimacionFInalizar = true
                            }
                            
                            DispatchQueue.main.asyncAfter(deadline: .now() + 2){
                                RemoverAnimacion = true
                            }
                        }
                    }
    }
}

#Preview {
    SplashScreen()
}
