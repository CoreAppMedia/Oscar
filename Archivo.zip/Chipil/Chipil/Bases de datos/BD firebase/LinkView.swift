//
//  LinkView.swift
//  SaveLink_1
//
//  Created by Oscar Valdes on 05/07/23.
//

import SwiftUI

struct LinkView: View {
    @ObservedObject var LinkViewModel: LinkViewModel
    @ObservedObject var authenticationViewModel: AuthenticationViewModel
    @State private var mostrar: Bool = false

    var body: some View {
            List{
                ForEach(LinkViewModel.links){ link in
                    VStack(alignment: .leading, spacing: 5){
                        HStack{
                            Text("Nombre:")
                                .bold()
                                .lineLimit(4)
                            Text("\(link.nombre) \(link.apellidoP) \(link.apellidoM)")
                                .bold()
                                .foregroundColor(.black)
                                .font(.caption)
                        }
                        HStack{
                            Text("Descripcion:")
                                .bold()
                                .lineLimit(4)
                            Text("\(link.descripcion)")
                                .bold()
                                .foregroundColor(.black)
                                .font(.caption)

                        }
                        HStack{
                            Text("Clasificación:")
                                .bold()
                                .lineLimit(4)
                            Text("\(link.titulo)")
                                .bold()
                                .foregroundColor(.black)
                                .font(.caption)
                        }
                        HStack{
                            Text("Numero de contacto: :")
                                .bold()
                                .lineLimit(4)
                            Text("\(link.numeroTel)")
                                .bold()
                                .foregroundColor(.black)
                                .font(.caption)

                        }
                        HStack{
                            Text("Nacio: ")
                                .bold()
                                .lineLimit(4)
                            Text("\(link.fecha)")
                                .bold()
                                .foregroundColor(.black)
                                .font(.caption)
                        }
                        Divider().background(.black)
                        
                    }//Vstack
                    .swipeActions(edge: .leading){
                        Button(action: {
                            LinkViewModel.delete(link: link)
                        }, label: {
                            Label("Eliminar", systemImage: "trash.fill")
                        })
                        .tint(.red)
                }
            }
                
                
                
                
                
                
                
                
            }.navigationBarTitleDisplayMode(.inline)
            .navigationTitle("Bienvenido \(authenticationViewModel.user?.email ?? "No usuario Master")")
                .toolbar{
                    ToolbarItem(placement: .navigationBarTrailing){
                        Button(action: {
                            self.mostrar.toggle()
                        }){
                            Image(systemName: "plus")
                                .resizable().frame(width: 20 ,height: 20)
                        }
                    }
                    
                }// llave Toolbar
                .sheet(isPresented: self.$mostrar,content: {
                    TestPerson(LinkViewModel: LinkViewModel)
                })
                .task {
        LinkViewModel.getAllLink()
}
        

    }
}

struct LinkView_Previews: PreviewProvider {
    static var previews: some View {
        LinkView(LinkViewModel: LinkViewModel(), authenticationViewModel: AuthenticationViewModel())
    }
}
