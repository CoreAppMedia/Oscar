//
//  MetadataDatasource.swift
//  SaveLink_1
//
//  Created by Oscar Valdes on 05/07/23.
//
// Este metodo se utiliza para obtener el titulo de un link  donde se instancias los daros para poder utilizarlos
import Foundation
import LinkPresentation

enum CustoMetadataError: Error{
    case badURL
}

final class MetadataDatasource{
    private var metadataProvider: LPMetadataProvider?
    
    func getMetadata(fromURL url: String, CompletionBlock: @escaping (Result<LinkModel, Error>)-> Void){
        guard let url = URL(string: url) else{
            CompletionBlock(.failure(CustoMetadataError.badURL))
            return
        }
        
        metadataProvider = LPMetadataProvider()
        metadataProvider?.startFetchingMetadata(for: url, completionHandler: { metadata, error in
            if let  error = error {
                print("Error en la Metadata \(error.localizedDescription)")
                CompletionBlock(.failure(error))
                return
            }
            let linkModel = LinkModel(id: "", 
                                      nombre: "Oscar",
                                      apellidoP: "Valdes",
                                      apellidoM: "Rodriguez",
                                      descripcion: "Estudiante de MAC",
                                      titulo: "Ansiedad",
                                      numeroTel: "5539")
            CompletionBlock(.success(linkModel))
            
        })
    }
}
