//
//  home_Menu.swift
//  Chipil
//
//  Created by Oscar Valdes on 18/09/23.
//

import SwiftUI

struct home_Menu: View {
    @Binding var selectedTable: String
    
    init(selectedTab: Binding<String>){
        self._selectedTable = selectedTab
    
        UITabBar.appearance().isHidden = true
    }
    
    var body: some View {
        
        TabView(selection: $selectedTable){
            
            
            inicio()
            //Text("holaaaaaa chipil")
        }
       
    }
}

struct home_Menu_Previews: PreviewProvider {
    static var previews: some View {
        ContentView(authenticationViewModel: AuthenticationViewModel())
        
    }
    
}

struct inicio: View{
    var body: some View{
        
        

            ZStack{
                
                Image("portada").frame(width: 300, height: 300).offset(x: 0,y: -400).shadow(radius: 10)
                
                Image("pie_de_pagina").frame(width: 300, height: 300).offset(x: 0,y: 400).shadow(radius: 5)
                VStack{
                    Text("Chipil App").font(.title).fontWeight(.black)
                        .offset(x: -120)
                    Spacer()
                    Image("Chipil_117")
                        .resizable().frame(width: 140 ,height: 240, alignment: .center)
                        .shadow(color: .black, radius:10)
                    Spacer()
                    
                    }//Vstack

                

                    
                }//Zstak


     
     
    }
}


