//
//  Side_Menu.swift
//  Chipil
//
//  Created by Oscar Valdes on 18/09/23.
//

import SwiftUI

struct Side_Menu: View {
    let persistenceController = PersistenceController.shared
    @UIApplicationDelegateAdaptor(AppDelegate.self) var delegate
    
    @Binding var selectedTable: String
    @Namespace var animation
    @State var isModal: Bool = false
    var body: some View {
        VStack(alignment: .leading, spacing: 15, content: {
            
            //Imagen del menu
            Image("Chipil_117")
                .resizable().aspectRatio( contentMode: .fill)
                .frame(width: 80, height: 140)
                .cornerRadius(30)
                .padding(.top,30)
                .shadow(color: .white, radius:10)
            VStack(alignment: .leading, spacing: 6, content: {
                Text("Chipil")
                    .padding(.top, 10)
                    .font(.title)
                    .fontWeight(.heavy)
                    .foregroundColor(.white)
                
            })
            
            Button("Creadores") {
                 self.isModal = true
             }.sheet(isPresented: $isModal, content: {
                 Credenciales()
             }).foregroundColor(.white).opacity(0.4)
                .fontWeight(.semibold)
                .padding(.top, -15)
            
            
            VStack(alignment: .leading, spacing: 5){
                NavigationLink{
                    LinkView(LinkViewModel: LinkViewModel(), authenticationViewModel: AuthenticationViewModel())
                } label: {
                    Image(systemName: "person.crop.square.fill").font(.system(size: 30, weight: .bold))
                   Text("Lista               ")
                }.fontWeight(.semibold)
                    .foregroundColor(Color.black)
                    .padding(.vertical,12)
                    .padding(.horizontal,20)
                    .background(.white)
                    .cornerRadius(15)
                
                    NavigationLink{
                        TestPerson(LinkViewModel: LinkViewModel())
                    } label: {
                        Image(systemName: "person.crop.square.fill").font(.system(size: 30, weight: .bold))
                        Text("Test                ")
                    }.fontWeight(.semibold)
                        .foregroundColor(Color.black)
                        .padding(.vertical,12)
                        .padding(.horizontal,20)
                        .background(.white)
                        .cornerRadius(15)
                
                NavigationLink{
                    ListNotas(authenticationViewModel: AuthenticationViewModel()).environment(\.managedObjectContext, persistenceController.container.viewContext)
                } label: {
                    Image(systemName: "list.bullet.clipboard").font(.system(size: 30, weight: .bold))
                   Text("Notas             ")
                }.fontWeight(.semibold)
                    .foregroundColor(Color.black)
                    .padding(.vertical,12)
                    .padding(.horizontal,20)
                    .background(.white)
                    .cornerRadius(15)

                NavigationLink{
                    LLAMADAS()
                } label: {
                    Image(systemName: "cross.case.fill").font(.system(size: 30, weight: .bold))
                   Text("Crisis           ")
                }.fontWeight(.semibold)
                    .foregroundColor(Color.black)
                    .padding(.vertical,12)
                    .padding(.horizontal,20)
                    .background(.white)
                    .cornerRadius(15)
                NavigationLink{
                    Mapas()
                    
                } label: {
                    Image(systemName: "house.circle.fill").font(.system(size: 30, weight: .bold))
                   Text("Ubicaciones")
                }.fontWeight(.semibold)
                    .foregroundColor(Color.black)
                    .padding(.vertical,12)
                    .padding(.horizontal,20)
                    .background(.white)
                    .cornerRadius(15)
                
                
             
                }
            .padding(.leading,-15)
            .padding(.top,50)
            
        })
        .padding()
        .frame(maxWidth: .infinity,maxHeight: .infinity, alignment: .topLeading)
        
        
    }
}

struct Side_Menu_Previews: PreviewProvider {
    static var previews: some View {
        ContentView(authenticationViewModel: AuthenticationViewModel())
    }
}

