//
//  HomeView.swift
//  Chipil
//
//  Created by Oscar Roberto Valdes on 17/09/23.
//

import SwiftUI

struct HomeView: View {
    
    @ObservedObject var authenticationViewModel: AuthenticationViewModel
    @StateObject var linkViewModel: LinkViewModel = LinkViewModel()
    var body: some View {
        
        NavigationView{
            VStack{
        MainView()
               // LinkView(LinkViewModel: LinkViewModel())
            }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                Button("Logout"){
                    authenticationViewModel.logout()
                }
                .tint(.black)
            }
        }
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView(authenticationViewModel: AuthenticationViewModel())
    }
}
