//
//  Credenciales.swift
//  Chipil
//
//  Created by Oscar Valdes on 18/09/23.
//

import SwiftUI

struct Credenciales: View {
    var body: some View {
        ZStack{
            Color("blue12").opacity(1).edgesIgnoringSafeArea(.all)//cambiar de color en fondo
            VStack{
                Image("FESA").resizable().aspectRatio( contentMode: .fill)
                    .frame(width: 300, height: 300)
                    .shadow(radius: 5)
                
                Divider()
                Text("Diseñadora grafica").font(.title).fontWeight(.black)
                    .shadow(radius: 5)
                Text("Avilez Pedroza ivon Dulce Anahí")
                    .fontWeight(.bold)
                Divider()
                Text("Programadores").font(.title).fontWeight(.black)
                    .shadow(radius: 5)
                Text("Moreno Robles Miriam").fontWeight(.bold)
                Text("Mejia Jacobo Ximena Juana").fontWeight(.bold)
                Text("Rios Avilès Dana Ixchel").fontWeight(.bold)
                Text("Valdes Rodriguez Oscar Roberto").fontWeight(.bold)
                   
                
            }
        }
    }
}

struct Credenciales_Previews: PreviewProvider {
    static var previews: some View {
        Credenciales()
    }
}
