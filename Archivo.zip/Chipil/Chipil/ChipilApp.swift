//
//  ChipilApp.swift
//  Chipil
//
//  Created by Oscar Roberto Valdes on 17/09/23.
//

import SwiftUI
import Firebase

class AppDelegate: NSObject, UIApplicationDelegate {
  func application(_ application: UIApplication,
                   didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
                    FirebaseApp.configure()
                    return true
  }
}

@main
struct ChipilApp: App {
    let persistenceController = PersistenceController.shared
    @UIApplicationDelegateAdaptor(AppDelegate.self) var delegate

    @StateObject var authenticationViewModel = AuthenticationViewModel()
    
    @State var AnimacionFInalizar: Bool = false
    @State var RemoverAnimacion: Bool = false
    
    
    var body: some Scene {
        WindowGroup {
            if let _ = authenticationViewModel.user{
                HomeView(authenticationViewModel: authenticationViewModel)
            }else{
                ContentView(authenticationViewModel: authenticationViewModel)

            }
                
        }
    }
}
