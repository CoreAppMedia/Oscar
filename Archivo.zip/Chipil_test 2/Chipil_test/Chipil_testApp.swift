//
//  Chipil_testApp.swift
//  Chipil_test
//
//  Created by ximena mejia  on 19/09/23.
//

import SwiftUI

@main
struct Chipil_testApp: App {
    var body: some Scene {
        WindowGroup {
                  ContentView()
               }
    }
}
