//
//  ChatGPTApp.swift
//  ChatGPT
//
//  Created by Oscar Valdes on 17/11/23.
//

import SwiftUI

@main
struct ChatGPTApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
